package service

import (
	"backend/internals/auth"
	"backend/internals/repository"
	"backend/model"
	"errors"
	"strings"
	"unicode"

	"golang.org/x/crypto/bcrypt"
)

var (
	ErrEmailTaken    = errors.New("an account with this email already exists")
	ErrUsernameTaken = errors.New("this username is already taken")
	ErrInvalidCreds  = errors.New("incorrect email or password")
	ErrWeakPassword  = errors.New("password must be at least 8 characters and contain a number")
)

type SignupRequest struct {
	Username string
	Email    string
	Password string
}

type LoginRequest struct {
	Email    string
	Password string
}

type AuthResponse struct {
	Token string     `json:"token"`
	User  PublicUser `json:"user"`
}

// PublicUser is the subset of model.User safe to send to the client.
type PublicUser struct {
	ID       uint   `json:"id"`
	Username string `json:"username"`
	Email    string `json:"email"`
	Role     string `json:"role"`
}

type AuthService struct {
	userRepo *repository.UserRepository
}

func NewAuthService(userRepo *repository.UserRepository) *AuthService {
	return &AuthService{userRepo: userRepo}
}

// Signup creates a new user account (role defaults to "user") and returns a JWT.
func (s *AuthService) Signup(req SignupRequest) (*AuthResponse, error) {
	req.Email = strings.ToLower(strings.TrimSpace(req.Email))
	req.Username = strings.TrimSpace(req.Username)

	if !isStrongPassword(req.Password) {
		return nil, ErrWeakPassword
	}

	existing, err := s.userRepo.FindByEmail(req.Email)
	if err != nil {
		return nil, err
	}
	if existing != nil {
		return nil, ErrEmailTaken
	}

	takenByUsername, err := s.userRepo.FindByUsername(req.Username)
	if err != nil {
		return nil, err
	}
	if takenByUsername != nil {
		return nil, ErrUsernameTaken
	}

	hash, err := bcrypt.GenerateFromPassword([]byte(req.Password), bcrypt.DefaultCost)
	if err != nil {
		return nil, err
	}

	user := &model.User{
		Username:     req.Username,
		Email:        req.Email,
		PasswordHash: string(hash),
		Role:         model.RoleUser, // new users are always "user"
	}
	if err := s.userRepo.CreateUser(user); err != nil {
		return nil, err
	}

	token, err := auth.GenerateToken(user.ID, user.Username, user.Email, string(user.Role))
	if err != nil {
		return nil, err
	}

	return &AuthResponse{
		Token: token,
		User:  toPublicUser(user),
	}, nil
}

// Login verifies credentials and returns a signed JWT carrying the user's role.
func (s *AuthService) Login(req LoginRequest) (*AuthResponse, error) {
	req.Email = strings.ToLower(strings.TrimSpace(req.Email))

	user, err := s.userRepo.FindByEmail(req.Email)
	if err != nil {
		return nil, err
	}
	if user == nil {
		return nil, ErrInvalidCreds
	}

	if err := bcrypt.CompareHashAndPassword([]byte(user.PasswordHash), []byte(req.Password)); err != nil {
		return nil, ErrInvalidCreds
	}

	token, err := auth.GenerateToken(user.ID, user.Username, user.Email, string(user.Role))
	if err != nil {
		return nil, err
	}

	return &AuthResponse{
		Token: token,
		User:  toPublicUser(user),
	}, nil
}

// ── Helpers ────────────────────────────────────────────────────────────────────

func toPublicUser(u *model.User) PublicUser {
	return PublicUser{
		ID:       u.ID,
		Username: u.Username,
		Email:    u.Email,
		Role:     string(u.Role),
	}
}

func isStrongPassword(p string) bool {
	if len(p) < 8 {
		return false
	}
	for _, r := range p {
		if unicode.IsDigit(r) {
			return true
		}
	}
	return false
}
