package service

import (
	"backend/internals/repository"
	"backend/model"
	"crypto/rand"
	"encoding/base64"
	"errors"
	"fmt"
	"strings"
)

type URLService struct{
	repo *repository.URLRepository
	cache *CacheService
}

func NewURLService(repo *repository.URLRepository, cache *CacheService,) *URLService {
	return &URLService{
        repo: repo,
        cache: cache,
    }

}

func(s *URLService) CreateShortURL(originalURL string, userID int) (*model.URL, error){
	if originalURL == ""{
		return nil, errors.New("url cannot be empty")
	}

	shortCode, err := genrateRandomCode(6)

	if err!= nil{
		return nil, err
	}
	
	urlModel := &model.URL{
		UserID:      uint(userID),
		OriginalURL: originalURL,
		ShortCode:   shortCode, // shortCode is now of type string
	}

	err = s.repo.Save(urlModel)
	err1 := s.cache.Put(shortCode,originalURL,3600,)
	if err!=nil{
		return nil, err
	}
	if err1!=nil{
		return nil, err
	}

	return urlModel, err
}

func(s *URLService) DeleteURL(shortCode string) error{
	return s.repo.Delete(shortCode)
}

func(s *URLService) GetURLsByUserID(userID int) ([]model.URL ,error){
	return s.repo.FindByUser(userID)
}

func (s *URLService) IncrementClickCount(shortCode string) error {
    return s.repo.IncrementClickCount(shortCode)
}

func(s *URLService) GetOriginalURL(shortCode string) (*model.URL, error){
	if shortCode == ""{
		return nil, errors.New("shortCode cannot be empty")
	}

	fmt.Println("Looking for:", shortCode)
	
	return s.repo.FindURLbyShortCode(shortCode)
}

func genrateRandomCode(i int) (string, error) {
	// Implement the logic to generate a random string of length i
	buffer := make([]byte, i)

	if _, err:= rand.Read(buffer); err != nil {
		return "", err
	}

	str := base64.URLEncoding.EncodeToString(buffer)
	str = strings.ReplaceAll(str, "_", "")
	str = strings.ReplaceAll(str, "-", "")
	if len(str) < i {
		return str, nil
	}
	return str[:i], nil
}

func (s *URLService) Resolve(shortCode string) (string, error) {

    if url, found, err := s.cache.Get(shortCode); err == nil && found {
        fmt.Println("CACHE HIT:", shortCode)
        return url, nil
    }

    fmt.Println("CACHE MISS:", shortCode)

    url, err := s.repo.FindByCode(shortCode)
    if err != nil {
        return "", err
    }

    err = s.cache.Put(shortCode, url, 3600)
    if err != nil {
        fmt.Println("CACHE PUT FAILED:", err)
    } else {
        fmt.Println("CACHE PUT SUCCESS:", shortCode)
    }

    return url, nil
}