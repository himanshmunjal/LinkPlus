package repository

import (
	"fmt"
	"log"

	"gorm.io/driver/postgres"
	"gorm.io/gorm"

	"backend/model"
)

func DBConnect() *gorm.DB {
	dsn := "host=localhost user=postgres password=1981 dbname=URL_Shortner port=5432"

	db, err := gorm.Open(postgres.Open(dsn), &gorm.Config{})
	if err != nil {
		log.Fatalf("Database connection failed: %v", err)
	}

	db.AutoMigrate(
		&model.URL{},
		&model.Clicks{},
		&model.User{},
	)

	if err != nil {
		log.Fatalf("Database migration failed: %v", err)
	}
	fmt.Println("Database migration completed successfully!")
	return db
}
