package model

import (
	"time"

	"gorm.io/gorm"
)

type Clicks struct {
	gorm.Model

	URLID     uint    `json:"url_id"`
	ShortCode string    `json:"short_code"`
	Device    string    `json:"device"`
	ClickedAt time.Time `json:"clickedat"`
	// Country   string    `json:"country"`   //To be added later on
}

type ClicksByDayResult struct {
	Date  string `json:"date"`
	Clicks int64  `json:"clicks"`
}

type TopLinksResult struct {
	ShortCode   string `json:"short_code"`
	OriginalURL string `json:"original_url"`
	Clicks      int64  `json:"Clicks" gorm:"column:click_count"`
}