// api.js — all API calls for the URL Shortener frontend.

const BASE      = import.meta.env.VITE_API_BASE ?? "http://localhost:8080";
const TOKEN_KEY = "url_shortner_token";

function getToken() {
  return localStorage.getItem(TOKEN_KEY);
}

async function request(path, options = {}, requiresAuth = false) {
  const headers = { "Content-Type": "application/json", ...options.headers };

  if (requiresAuth) {
    const token = getToken();
    if (!token) throw new Error("Not authenticated");
    headers["Authorization"] = `Bearer ${token}`;
  }

  const res = await fetch(`${BASE}${path}`, { ...options, headers });

  if (!res.ok) {
    if (res.status === 401) {
      window.dispatchEvent(new Event("auth:unauthorized"));
    }
    const body = await res.json().catch(() => ({}));
    throw new Error(body.error ?? `HTTP ${res.status}`);
  }

  return res.json();
}

// ── Auth ──────────────────────────────────────────────────────────────────────

export const signup = (username, email, password) =>
  request("/api/v1/auth/signup", {
    method: "POST",
    body: JSON.stringify({ username, email, password }),
  });

export const login = (email, password) =>
  request("/api/v1/auth/login", {
    method: "POST",
    body: JSON.stringify({ email, password }),
  });

export const getMe = () => request("/api/v1/auth/me", {}, true);

// ── URLs ──────────────────────────────────────────────────────────────────────

export const createURL = (url) =>
  request("/api/v1/url", { method: "POST", body: JSON.stringify({ url }) }, true);

export const getMyURLs = () => request("/api/v1/url", {}, true);

export const deleteURL = (code) =>
  request(`/api/v1/url/${code}`, { method: "DELETE" }, true);

// ── Analytics ─────────────────────────────────────────────────────────────────

export const getTopLinks    = ()     => request("/api/v1/analytics/top",           {}, true);
export const getDailyClicks = (code) => request(`/api/v1/analytics/daily/${code}`, {}, true);
export const getTotalClicks = ()     => request("/api/v1/analytics/total",          {}, true);

export const getMyTotalClicks = () => request("/api/v1/analytics/total/me", {}, true);
export const getDailyClicksByUser = () => request("/api/v1/analytics/daily", {}, true);

// ── Cache (admin only) ────────────────────────────────────────────────────────

export const getCacheStats = () => request("/api/v1/admin/cache/stats", {}, true);


// ── Helpers ───────────────────────────────────────────────────────────────────

export const shortURL = (code) => `${BASE}/r/${code}`;
