// Architecture.jsx — V3: updated to include QR Code Generator in the flow and stack.

import {
  Monitor, Server, Zap, Database, ArrowDown, Shield,
  PenSquare, MousePointerClick, QrCode, ScanLine,
} from "lucide-react";
import { PageHeader, Card, Badge } from "../components/ui";

const SHORT_URL_FLOW = [
  { icon: Monitor, title: "React Frontend",      detail: "Vite · Tailwind CSS · Recharts · lucide-react" },
  { icon: Server,  title: "Go API (Gin)",        detail: "JWT auth middleware · request validation · CORS" },
  { icon: Zap,     title: "JCache",              detail: "Custom in-memory cache · TCP protocol · 1-hour TTL" },
  { icon: Database,title: "PostgreSQL",          detail: "urls, clicks, users, refresh_tokens tables" },
];

const QR_FLOW = [
  { icon: Monitor,  title: "React Frontend",     detail: "QR Code form → POST /api/v1/qr" },
  { icon: Server,   title: "Go API (Gin)",       detail: "go-qrcode library generates PNG in memory" },
  { icon: Database, title: "PostgreSQL",         detail: "qr_codes + qr_scans tables — no cache needed" },
];

const STACK = {
  Frontend:  ["React 19", "Vite", "Tailwind CSS v4", "Recharts", "lucide-react"],
  Backend:   ["Go", "Gin", "GORM", "JWT (HS256)", "bcrypt", "go-qrcode"],
  Data:      ["PostgreSQL", "JCache (custom TCP cache)"],
};

function FlowNode({ icon: Icon, title, detail }) {
  return (
    <div className="rounded-2xl border border-zinc-200 dark:border-zinc-800 bg-white dark:bg-zinc-900/50 p-5 flex items-center gap-4">
      <span className="flex items-center justify-center w-11 h-11 rounded-xl bg-zinc-100 dark:bg-zinc-800 text-zinc-700 dark:text-zinc-200 shrink-0">
        <Icon className="w-5 h-5" strokeWidth={1.75} />
      </span>
      <div className="min-w-0">
        <p className="font-semibold text-zinc-900 dark:text-white">{title}</p>
        <p className="text-sm text-zinc-500 dark:text-zinc-400 truncate">{detail}</p>
      </div>
    </div>
  );
}

function FlowArrow() {
  return (
    <div className="flex justify-center py-1">
      <ArrowDown className="w-4 h-4 text-zinc-400 dark:text-zinc-600 animate-pulse-dot" strokeWidth={2} />
    </div>
  );
}

function InfoCard({ icon: Icon, title, children }) {
  return (
    <Card className="p-6">
      <div className="flex items-center gap-3 mb-3">
        <span className="flex items-center justify-center w-9 h-9 rounded-lg bg-zinc-100 dark:bg-zinc-800 text-zinc-700 dark:text-zinc-200 shrink-0">
          <Icon className="w-4.5 h-4.5" strokeWidth={1.75} />
        </span>
        <h3 className="font-semibold text-zinc-900 dark:text-white">{title}</h3>
      </div>
      <p className="text-sm text-zinc-500 dark:text-zinc-400 leading-relaxed">{children}</p>
    </Card>
  );
}

export default function Architecture() {
  return (
    <div className="space-y-8">
      <PageHeader title="System Architecture" description="How LinkPlus V3 handles short links and QR codes end-to-end." />

      {/* ── Two flows side by side ── */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card className="p-6 sm:p-8">
          <div className="mb-6">
            <h2 className="font-semibold text-lg text-zinc-900 dark:text-white flex items-center gap-2">
              <MousePointerClick className="w-4 h-4" /> Short URL flow
            </h2>
            <p className="text-sm text-zinc-500 dark:text-zinc-400 mt-1">
              Cache-aside lookup with async click tracking
            </p>
          </div>
          <div className="max-w-md mx-auto">
            {SHORT_URL_FLOW.map((node, i) => (
              <div key={node.title}>
                <FlowNode {...node} />
                {i < SHORT_URL_FLOW.length - 1 && <FlowArrow />}
              </div>
            ))}
          </div>
        </Card>

        <Card className="p-6 sm:p-8">
          <div className="mb-6">
            <h2 className="font-semibold text-lg text-zinc-900 dark:text-white flex items-center gap-2">
              <QrCode className="w-4 h-4" /> QR Code flow
            </h2>
            <p className="text-sm text-zinc-500 dark:text-zinc-400 mt-1">
              On-demand PNG generation — no redirect, no cache
            </p>
          </div>
          <div className="max-w-md mx-auto">
            {QR_FLOW.map((node, i) => (
              <div key={node.title}>
                <FlowNode {...node} />
                {i < QR_FLOW.length - 1 && <FlowArrow />}
              </div>
            ))}
          </div>
        </Card>
      </div>

      {/* ── Feature info cards ── */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <InfoCard icon={Zap} title="Cache-aside pattern (short URLs)">
          On every redirect lookup the API checks JCache first. On a miss it loads
          the original URL from PostgreSQL, writes it back into JCache with a fresh
          1-hour TTL, and then sends the redirect — so every subsequent request for
          the same code is served straight from memory.
        </InfoCard>

        <InfoCard icon={QrCode} title="QR Code generation">
          The Go backend uses the skip2/go-qrcode library to generate a PNG
          entirely in memory — no temporary files. The image is returned as a
          base64 data URI on creation so the frontend can display and offer a
          download in a single round trip. Scans are tracked via a dedicated
          qr_scans table with the same device + geo pipeline as short URL clicks.
        </InfoCard>

        <InfoCard icon={MousePointerClick} title="Click & scan tracking">
          Both redirects and QR scan events return to the user instantly. The
          device detection (user-agent parsing), IP geo-lookup, and DB write all
          happen in background goroutines so tracking never adds latency to the
          response. Device types: Desktop, iPhone, iPad, Android, Mobile, Tablet.
        </InfoCard>

        <InfoCard icon={ScanLine} title="Unified analytics">
          The Analytics page has separate tabs for Short URL and QR Code metrics.
          Both surfaces expose: total volume, daily trend charts, device breakdown
          donut, and top-performers table. Country breakdown is also available
          for short URL clicks (powered by the MaxMind GeoIP resolver).
        </InfoCard>

        <InfoCard icon={PenSquare} title="Write path">
          Creating a short link generates a random 6-character code, saves it in
          PostgreSQL, and immediately seeds JCache with the same TTL — so the
          very first redirect is already a cache hit. Creating a QR code only
          writes to PostgreSQL (no cache entry needed since the PNG is generated
          on-demand from the stored URL).
        </InfoCard>

        <InfoCard icon={Shield} title="Authentication">
          Signup and login hash passwords with bcrypt and issue a 24-hour JWT
          (HS256) carrying the user's id, username, and email. A refresh-token
          flow extends sessions without re-login. Every protected route runs a
          Gin middleware that validates the bearer token — user identity comes
          from the token, never a client-supplied id.
        </InfoCard>
      </div>

      {/* ── Stack ── */}
      <Card className="p-6">
        <h3 className="font-semibold text-zinc-900 dark:text-white mb-4">Built with</h3>
        <div className="space-y-4">
          {Object.entries(STACK).map(([layer, items]) => (
            <div key={layer} className="flex flex-wrap items-center gap-2">
              <span className="text-xs font-semibold uppercase tracking-widest text-zinc-400 w-20 shrink-0">
                {layer}
              </span>
              {items.map((item) => (
                <Badge key={item} tone="outline">{item}</Badge>
              ))}
            </div>
          ))}
        </div>
      </Card>
    </div>
  );
}
