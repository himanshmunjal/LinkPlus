-- Clicks table indexes
-- Composite: covers both WHERE short_code = ? AND ORDER BY clicked_at
CREATE INDEX IF NOT EXISTS idx_clicks_short_code_clicked_at
    ON clicks (short_code, clicked_at DESC)
    WHERE deleted_at IS NULL;

-- Country grouping for geo analytics dashboard
CREATE INDEX IF NOT EXISTS idx_clicks_country
    ON clicks (country)
    WHERE deleted_at IS NULL AND country != '';

-- For joining clicks → urls by url_id
CREATE INDEX IF NOT EXISTS idx_clicks_url_id
    ON clicks (url_id)
    WHERE deleted_at IS NULL;

-- URLs table indexes
-- User's own URLs list
CREATE INDEX IF NOT EXISTS idx_urls_user_id
    ON urls (user_id)
    WHERE deleted_at IS NULL;

-- Top links by click_count
CREATE INDEX IF NOT EXISTS idx_urls_click_count_desc
    ON urls (click_count DESC)
    WHERE deleted_at IS NULL;

-- Users table
CREATE INDEX IF NOT EXISTS idx_users_email
    ON users (email)
    WHERE deleted_at IS NULL;