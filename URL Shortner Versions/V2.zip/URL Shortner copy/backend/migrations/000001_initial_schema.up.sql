CREATE TABLE IF NOT EXISTS users (
    id          BIGSERIAL PRIMARY KEY,
    created_at  TIMESTAMPTZ,
    updated_at  TIMESTAMPTZ,
    deleted_at  TIMESTAMPTZ,
    username    TEXT NOT NULL UNIQUE,
    email       TEXT NOT NULL UNIQUE,
    password_hash    TEXT NOT NULL,
    role        TEXT NOT NULL DEFAULT 'user'
);

CREATE TABLE IF NOT EXISTS urls (
    id           BIGSERIAL PRIMARY KEY,
    created_at   TIMESTAMPTZ,
    updated_at   TIMESTAMPTZ,
    deleted_at   TIMESTAMPTZ,
    user_id      BIGINT NOT NULL REFERENCES users(id),
    original_url TEXT NOT NULL,
    short_code   TEXT NOT NULL,
    click_count  BIGINT DEFAULT 0,
    CONSTRAINT urls_short_code_unique UNIQUE (short_code)
);

CREATE TABLE IF NOT EXISTS clicks (
    id         BIGSERIAL PRIMARY KEY,
    created_at TIMESTAMPTZ,
    updated_at TIMESTAMPTZ,
    deleted_at TIMESTAMPTZ,
    url_id     BIGINT REFERENCES urls(id) ON DELETE CASCADE,
    short_code TEXT,
    device     TEXT,
    clicked_at TIMESTAMPTZ
);