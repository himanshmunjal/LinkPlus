ALTER TABLE urls
    ADD COLUMN IF NOT EXISTS expires_at TIMESTAMPTZ DEFAULT NULL;

-- Partial index: only index rows that actually have an expiry set
-- The background worker query is: WHERE expires_at IS NOT NULL AND expires_at < NOW()
CREATE INDEX IF NOT EXISTS idx_urls_expires_at
    ON urls (expires_at)
    WHERE expires_at IS NOT NULL AND deleted_at IS NULL;