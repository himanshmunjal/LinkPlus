package cache

import (
	"context"
	"time"

	"github.com/redis/go-redis/v9"
)

type RedisClient struct {
	client *redis.Client
	ctx    context.Context
}

func NewRedisClient(addr string) *RedisClient {

	rdb := redis.NewClient(&redis.Options{
		Addr:           addr,
		PoolSize:     10,
		MinIdleConns: 2,
		ReadTimeout:  3 * time.Second,
		WriteTimeout: 3 * time.Second,
	})

	return &RedisClient{
		client: rdb,
		ctx:    context.Background(),
	}
}

func (r *RedisClient) Get(key string) (string, bool, error) {

	val, err := r.client.Get(
		r.ctx,
		key,
	).Result()

	if err == redis.Nil {
		return "", false, nil
	}

	if err != nil {
		return "", false, err
	}

	return val, true, nil
}

func (r *RedisClient) Put(
	key string,
	value string,
	ttlSeconds int,
) error {

	return r.client.Set(
		r.ctx,
		key,
		value,
		time.Duration(ttlSeconds)*time.Second,
	).Err()
}

func (r *RedisClient) Delete(key string) error {

	return r.client.Del(
		r.ctx,
		key,
	).Err()
}

func (r *RedisClient) Ping() error {

	return r.client.Ping(
		r.ctx,
	).Err()
}

func (r *RedisClient) Close() error {

	return r.client.Close()
}