package middleware

import (
	"context"
	"fmt"
	"net/http"
	"time"

	"github.com/gin-gonic/gin"
	"github.com/redis/go-redis/v9"
)

func SlidingWindowLimiter(client *redis.Client, key func(c *gin.Context) string, limit int, window time.Duration) gin.HandlerFunc{
	return func(c *gin.Context) {
		k := "rl:" + key(c)
		now := time.Now()
		windowStart := now.Add(-window)
		ctx := context.Background()

		script := `
            local key = KEYS[1]
            local now = tonumber(ARGV[1])
            local window_start = tonumber(ARGV[2])
            local limit = tonumber(ARGV[3])
            local ttl = tonumber(ARGV[4])

            redis.call("ZREMRANGEBYSCORE", key, "-inf", window_start)
            local count = redis.call("ZCARD", key)
            if count < limit then
                redis.call("ZADD", key, now, now)
                redis.call("EXPIRE", key, ttl)
                return 1
            end
            return 0
        `

		result, err := client.Eval(ctx, script,
			[]string{k},
			now.UnixNano(),
			windowStart.UnixNano(),
			limit,
			int(window.Seconds())+1,
		).Int()

		if err != nil || result == 0 {
			c.Header("Retry-After", fmt.Sprintf("%d", int(window.Seconds())))
			c.AbortWithStatusJSON(http.StatusTooManyRequests, gin.H{
				"error": "rate limit exceeded — slow down",
			})
			return
		}

		c.Next()
	}
}

func KeyByUserID(c *gin.Context) string {
	// Checks if an auth middleware saved the userID to the request context
	if userID, exists := c.Get("userID"); exists {
		return fmt.Sprintf("%v", userID)
	}
	
	// Fallback to IP address if request is unauthenticated or context missing
	return c.ClientIP()
}