// // api.js — all API calls for the URL Shortener frontend.

// const BASE      = import.meta.env.VITE_API_BASE ?? "http://localhost:8080";
// const TOKEN_KEY = "url_shortner_token";

// function getToken() {
//   return localStorage.getItem(TOKEN_KEY);
// }

// async function request(path, options = {}, requiresAuth = false) {
//   const headers = { "Content-Type": "application/json", ...options.headers };

//   if (requiresAuth) {
//     const token = getToken();
//     if (!token) throw new Error("Not authenticated");
//     headers["Authorization"] = `Bearer ${token}`;
//   }

//   const res = await fetch(`${BASE}${path}`, { ...options, headers });

//   if (!res.ok) {
//     if (res.status === 401) {
//       window.dispatchEvent(new Event("auth:unauthorized"));
//     }
//     const body = await res.json().catch(() => ({}));
//     throw new Error(body.error ?? `HTTP ${res.status}`);
//   }

//   return res.json();
// }

// // ── Auth ──────────────────────────────────────────────────────────────────────

// export const signup = (username, email, password) =>
//   request("/api/v1/auth/signup", {
//     method: "POST",
//     body: JSON.stringify({ username, email, password }),
//   });

// export const login = (email, password) =>
//   request("/api/v1/auth/login", {
//     method: "POST",
//     body: JSON.stringify({ email, password }),
//   });

// export const getMe = () => request("/api/v1/auth/me", {}, true);

// // ── URLs ──────────────────────────────────────────────────────────────────────

// export const createURL = (url) =>
//   request("/api/v1/url", { method: "POST", body: JSON.stringify({ url }) }, true);

// export const getMyURLs = () => request("/api/v1/url", {}, true);

// export const deleteURL = (code) =>
//   request(`/api/v1/url/${code}`, { method: "DELETE" }, true);

// // ── Analytics ─────────────────────────────────────────────────────────────────

// export const getTopLinks    = ()     => request("/api/v1/analytics/top",           {}, true);
// export const getDailyClicks = (code) => request(`/api/v1/analytics/daily/${code}`, {}, true);
// export const getTotalClicks = ()     => request("/api/v1/analytics/total",          {}, true);

// export const getMyTotalClicks = () => request("/api/v1/analytics/total/me", {}, true);
// export const getDailyClicksByUser = () => request("/api/v1/analytics/daily", {}, true);

// // ── Cache (admin only) ────────────────────────────────────────────────────────

// export const getCacheStats = () => request("/api/v1/admin/cache/stats", {}, true);


// // ── Helpers ───────────────────────────────────────────────────────────────────

// export const shortURL = (code) => `${BASE}/r/${code}`;

// api.js — all API calls for the URL Shortener frontend.

const BASE = import.meta.env.VITE_API_BASE ?? "http://localhost:8080";

const ACCESS_TOKEN_KEY = "access_token";
const REFRESH_TOKEN_KEY = "refresh_token";

function getAccessToken() {
  return localStorage.getItem(ACCESS_TOKEN_KEY);
}

function getRefreshToken() {
  return localStorage.getItem(REFRESH_TOKEN_KEY);
}

export function saveAuth(data) {
  localStorage.setItem(ACCESS_TOKEN_KEY, data.token);
  localStorage.setItem(REFRESH_TOKEN_KEY, data.refresh_token);
}

export function clearAuth() {
  localStorage.removeItem(ACCESS_TOKEN_KEY);
  localStorage.removeItem(REFRESH_TOKEN_KEY);
}

async function refreshAccessToken() {
  const refreshToken = getRefreshToken();

  if (!refreshToken) {
    throw new Error("No refresh token available");
  }

  const res = await fetch(`${BASE}/api/v1/auth/refresh`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      refresh_token: refreshToken,
    }),
  });

  if (!res.ok) {
    clearAuth();
    throw new Error("Session expired");
  }

  const data = await res.json();

  localStorage.setItem(
    ACCESS_TOKEN_KEY,
    data.access_token
  );

  localStorage.setItem(
    REFRESH_TOKEN_KEY,
    data.refresh_token
  );

  window.dispatchEvent(new CustomEvent("auth:refreshed", { detail: data.access_token }));
  return data.access_token;
}

async function request(path, options = {}, requiresAuth = false) {
  const headers = {
    "Content-Type": "application/json",
    ...options.headers,
  };

  if (requiresAuth) {
    const token = getAccessToken();

    if (!token) {
      throw new Error("Not authenticated");
    }

    headers["Authorization"] = `Bearer ${token}`;
  }

  let res = await fetch(`${BASE}${path}`, {
    ...options,
    headers,
  });

  // Access token expired → try refresh
  if (res.status === 401 && requiresAuth) {
    try {
      const newAccessToken = await refreshAccessToken();

      headers["Authorization"] = `Bearer ${newAccessToken}`;

      res = await fetch(`${BASE}${path}`, {
        ...options,
        headers,
      });
    } catch (err) {
      clearAuth();
      window.dispatchEvent(new Event("auth:unauthorized"));
      throw err;
    }
  }

  if (!res.ok) {
    const body = await res.json().catch(() => ({}));

    throw new Error(
      body.error ?? `HTTP ${res.status}`
    );
  }

  return res.json();
}

// Auth

export const signup = (username, email, password) => request("/api/v1/auth/signup", {
    method: "POST",
    body: JSON.stringify({
      username,
      email,
      password,
    }),
  });

export const login = (email, password) => request("/api/v1/auth/login", {
    method: "POST",
    body: JSON.stringify({
      email,
      password,
    }),
  });

export const getMe = () => request("/api/v1/auth/me", {}, true);

// URLs

export const createURL = (url, expiresIn) =>
  request(
    "/api/v1/url",
    {
      method: "POST",
      body: JSON.stringify({
        url,
        expires_in: expiresIn || 0,
      }),
    },
    true
  );

export const getMyURLs = () => request("/api/v1/url", {}, true);

export const deleteURL = (code) => request(`/api/v1/url/${code}`, { method: "DELETE" }, true);

// ─────────────────────────────────────────────
// Analytics
// ─────────────────────────────────────────────

export const getTopLinks = () => request("/api/v1/analytics/top", {}, true);

export const getDailyClicks = (code) => request(`/api/v1/analytics/daily/${code}`, {}, true);

export const getTotalClicks = () => request("/api/v1/analytics/total", {}, true);

export const getMyTotalClicks = () => request("/api/v1/analytics/total/me", {}, true);

export const getDailyClicksByUser = () => request("/api/v1/analytics/daily", {}, true);

// Admin

export const getCacheStats = () => request("/api/v1/admin/cache/stats", {}, true);

export const shortURL = (code) => `${BASE}/r/${code}`;