// Architecture.jsx — a static, informational page explaining how a request
// actually moves through LinkPulse. Content is grounded in the real backend
// code (cache-aside read path, TTL on every cache write, async click
// tracking, JWT auth) rather than generic boilerplate.

import { Monitor, Server, Zap, Database, ArrowDown, Shield, PenSquare, MousePointerClick } from "lucide-react";
import { PageHeader, Card, Badge } from "../components/ui";

const FLOW = [
  {
    icon: Monitor,
    title: "React Frontend",
    detail: "Vite · Tailwind CSS · Recharts · lucide-react",
  },
  {
    icon: Server,
    title: "Go API",
    detail: "Gin REST endpoints · JWT middleware · request validation",
  },
  {
    icon: Zap,
    title: "JCache",
    detail: "Custom in-memory cache · TCP protocol · 1-hour TTL",
  },
  {
    icon: Database,
    title: "PostgreSQL",
    detail: "Durable storage for users, links, and click events",
  },
];

const STACK = {
  Frontend: ["React 19", "Vite", "Tailwind CSS v4", "Recharts", "lucide-react"],
  Backend: ["Go", "Gin", "GORM", "JWT (HS256)", "bcrypt"],
  Data: ["PostgreSQL", "JCache (custom TCP cache)"],
};

function FlowNode({ icon: Icon, title, detail }) {
  return (
    <div className="rounded-2xl border border-zinc-200 dark:border-zinc-800 bg-white dark:bg-zinc-900/50 p-5 flex items-center gap-4">
      <span className="flex items-center justify-center w-11 h-11 rounded-xl bg-zinc-100 dark:bg-zinc-800 text-zinc-700 dark:text-zinc-200 shrink-0">
        <Icon className="w-5 h-5" strokeWidth={1.75} />
      </span>
      <div className="min-w-0">
        <p className="font-semibold text-zinc-900 dark:text-white">{title}</p>
        <p className="text-sm text-zinc-500 dark:text-zinc-400 truncate">{detail}</p>
      </div>
    </div>
  );
}

function FlowArrow() {
  return (
    <div className="flex justify-center py-1">
      <ArrowDown className="w-4 h-4 text-zinc-400 dark:text-zinc-600 animate-pulse-dot" strokeWidth={2} />
    </div>
  );
}

function InfoCard({ icon: Icon, title, children }) {
  return (
    <Card className="p-6">
      <div className="flex items-center gap-3 mb-3">
        <span className="flex items-center justify-center w-9 h-9 rounded-lg bg-zinc-100 dark:bg-zinc-800 text-zinc-700 dark:text-zinc-200 shrink-0">
          <Icon className="w-[18px] h-[18px]" strokeWidth={1.75} />
        </span>
        <h3 className="font-semibold text-zinc-900 dark:text-white">{title}</h3>
      </div>
      <p className="text-sm text-zinc-500 dark:text-zinc-400 leading-relaxed">{children}</p>
    </Card>
  );
}

export default function Architecture() {
  return (
    <div className="space-y-8">
      <PageHeader title="System Architecture" description="How LinkPulse handles a request end-to-end." />

      <Card className="p-6 sm:p-8">
        <div className="mb-6">
          <h2 className="font-semibold text-lg text-zinc-900 dark:text-white">Request flow</h2>
          <p className="text-sm text-zinc-500 dark:text-zinc-400 mt-1">
            Top-to-bottom traversal for a short-link lookup
          </p>
        </div>

        <div className="max-w-xl mx-auto">
          {FLOW.map((node, i) => (
            <div key={node.title}>
              <FlowNode {...node} />
              {i < FLOW.length - 1 && <FlowArrow />}
            </div>
          ))}
        </div>
      </Card>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <InfoCard icon={Zap} title="Cache-aside pattern">
          On every redirect lookup, the API checks JCache first. On a miss, it loads the
          original URL from PostgreSQL, writes that value back into JCache with a fresh TTL,
          and only then sends the redirect — so the next request for the same code is served
          straight from memory.
        </InfoCard>

        <InfoCard icon={Database} title="TTL on every write">
          Every cache write — whether it's the cache-aside fill on a miss or the seed write
          when a link is first created — carries a one-hour TTL. Once a key expires, the next
          lookup simply falls through to PostgreSQL and refills the cache.
        </InfoCard>

        <InfoCard icon={PenSquare} title="Write path">
          Creating a link generates a random six-character code, saves the row in PostgreSQL,
          and immediately seeds JCache with the same TTL — so the very first redirect for a
          brand-new link is already a cache hit.
        </InfoCard>

        <InfoCard icon={MousePointerClick} title="Click tracking">
          Redirects return immediately; incrementing the click counter and logging the click
          event (with a simple device type parsed from the user agent) happen in background
          goroutines so tracking never adds latency to the redirect itself.
        </InfoCard>
      </div>

      <Card className="p-6">
        <div className="flex items-center gap-3 mb-4">
          <span className="flex items-center justify-center w-9 h-9 rounded-lg bg-zinc-100 dark:bg-zinc-800 text-zinc-700 dark:text-zinc-200">
            <Shield className="w-[18px] h-[18px]" strokeWidth={1.75} />
          </span>
          <div>
            <h3 className="font-semibold text-zinc-900 dark:text-white">Authentication</h3>
            <p className="text-xs text-zinc-400">Stateless, bearer-token based</p>
          </div>
        </div>
        <p className="text-sm text-zinc-500 dark:text-zinc-400 leading-relaxed">
          Signup and login hash passwords with bcrypt and issue a 24-hour JWT (HS256) carrying
          the user's id, username, and email. Every protected route runs through a Gin
          middleware that validates the bearer token before the handler executes — the user's
          identity comes from the token, never from a client-supplied id.
        </p>
      </Card>

      <Card className="p-6">
        <h3 className="font-semibold text-zinc-900 dark:text-white mb-4">Built with</h3>
        <div className="space-y-4">
          {Object.entries(STACK).map(([layer, items]) => (
            <div key={layer} className="flex flex-wrap items-center gap-2">
              <span className="text-xs font-semibold uppercase tracking-widest text-zinc-400 w-20 shrink-0">
                {layer}
              </span>
              {items.map((item) => (
                <Badge key={item} tone="outline">
                  {item}
                </Badge>
              ))}
            </div>
          ))}
        </div>
      </Card>
    </div>
  );
}
