// Analytics.jsx — click performance dashboard matching the 4-panel design:
//   • Stats row (total clicks, top link, tracked links)
//   • Daily clicks area chart  ← real DB data per selected short code
//   • Top 10 URLs bar chart     ← real DB data
//   • Device distribution donut ← demo data (not stored in DB)
//   • Share of clicks donut     ← real DB data, properly coloured

import { useEffect, useMemo, useState } from "react";
import { MousePointerClick, Trophy, Link2 } from "lucide-react";
import { getMyURLs, getDailyClicks, getMyTotalClicks, getDailyClicksByUser } from "../api/api";
import { PageHeader, Card, ErrorBanner } from "../components/ui";
import StatsCard from "../components/StatsCard";
import TopLinksTable from "../components/TopLinksTable";
import {
  AreaTrend,
  BarTrend,
  DonutStat,
  ChartLegend,
  ChartSkeleton,
  ChartEmpty,
} from "../components/charts";
import { formatNumber } from "../lib/format";

// Colour palette for the two donuts 
const SHARE_COLORS = [
  "#3b82f6",
  "#22c55e",
  "#f97316",
  "#a855f7",
  "#ef4444",
];

export default function Analytics() {
  const [topLinks,     setTopLinks]     = useState([]);
  const [totalClicks,  setTotalClicks]  = useState(null);
  const [dailyData,    setDailyData]    = useState([]);
  const [selectedCode, setSelectedCode] = useState(null);
  const [loading,      setLoading]      = useState(true);
  const [dailyLoading, setDailyLoading] = useState(false);
  const [error,        setError]        = useState(null);
  const [dailyDataByUser,    setDailyDataByUser]     = useState([]);
  // const [loader,      loadDailyByUser]      = useState(true);


  useEffect(() => {
    Promise.all([
      getMyURLs(),
      getMyTotalClicks(),
      getDailyClicksByUser()
    ])
      .then(([top, total, dailyUser]) => {
        const list = top ?? [];
        setTopLinks(list);
        setTotalClicks(total?.total_clicks ?? 0);
        setDailyDataByUser(dailyUser ?? []);

        if (list.length > 0) loadDaily(list[0].short_code);
      })
      .catch((e) => setError(e.message))
      .finally(() => setLoading(false));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const loadDailyByUser = async () => {
    try {
      const data = await getDailyClicksByUser();
      setDailyDataByUser(data ?? []);
    } catch {
      setDailyDataByUser([]);
    }
  };

  const loadDaily = async (code) => {
    setSelectedCode(code);
    setDailyLoading(true);
    try {
      const data = await getDailyClicks(code);
      setDailyData(data ?? []);
    } catch {
      setDailyData([]);
    } finally {
      setDailyLoading(false);
    }
  };

  // Share-of-clicks donut data — from real top links
  const shareData = useMemo(
    () =>
      topLinks.slice(0, 5).map((l, i) => ({
        name:  l.short_code,
        value: l.click_count ?? 0,
        color: SHARE_COLORS[i % SHARE_COLORS.length],
      })),
    [topLinks]
  );

  // Bar chart data for Top 10 URLs
  const barData = useMemo(
    () => topLinks.slice(0, 10).map((l) => ({ code: l.short_code, click_count: l.click_count ?? 0 })),
    [topLinks]
  );

  if (error) {
    return (
      <div className="space-y-6">
        <PageHeader title="Analytics" description="Click performance across all tracked links." />
        <ErrorBanner>{error}</ErrorBanner>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      <PageHeader
        title="Analytics"
        description="Click performance across all tracked links on LinkPulse."
      />

      {/* ── Stats row ── */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <StatsCard
          label="Total clicks"
          value={loading ? "…" : formatNumber(totalClicks ?? 0)}
          sub="across all LinkPulse links"
          icon={MousePointerClick}
        />
        <StatsCard
          label="Top link clicks"
          value={loading ? "…" : formatNumber(topLinks[0]?.click_count ?? 0)}
          sub={topLinks[0]?.short_code ?? "—"}
          icon={Trophy}
          tone="success"
        />
        <StatsCard
          label="Tracked links"
          value={loading ? "…" : formatNumber(topLinks.length)}
          icon={Link2}
        />
      </div>

      {/* ── Row 1: Daily clicks + Top 10 URLs bar ── */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Daily clicks area */}
        <Card className="p-6">
          <h2 className="font-semibold text-zinc-900 dark:text-white mb-1">Daily clicks</h2>
          <p className="text-xs text-zinc-400 mb-4">
            {selectedCode ? (
              <>Last 30 days for{" "}
                <span className="font-mono text-zinc-600 dark:text-zinc-300">{selectedCode}</span>
              </>
            ) : (
              "Select a link from the table below"
            )}
          </p>
          {dailyLoading ? (
            <ChartSkeleton height={220} />
          ) : (
            <AreaTrend
              data={dailyData}
              xKey="date"
              yKey="clicks"
              height={220}
              color="var(--chart-blue)"
            />
          )}
        </Card>

        {/* Top 10 URLs bar */}
        <Card className="p-6">
          <h2 className="font-semibold text-zinc-900 dark:text-white mb-1">Top 10 URLs</h2>
          <p className="text-xs text-zinc-400 mb-4">By total clicks</p>
          {loading ? (
            <ChartSkeleton height={220} />
          ) : barData.length === 0 ? (
            <ChartEmpty />
          ) : (
            <BarTrend
              data={barData}
              xKey="code"
              yKey="click_count"
              height={220}
              color="var(--chart-success)"
              barName="Clicks"
            />
          )}
        </Card>
      </div>

      {/* ── Row 2: Device distribution (demo) + Share of clicks (real) ── */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card className="p-6">
          <h2 className="font-semibold text-zinc-900 dark:text-white mb-1">Month wise Daily clicks</h2>
          <p className="text-xs text-zinc-400 mb-4">
            {selectedCode ? (
              <>Total last 30 days clicks
              </>
            ) : (
              "Select a link from the table below"
            )}
          </p>
          {dailyLoading ? (
            <ChartSkeleton height={220} />
          ) : (
            <AreaTrend
            data={dailyDataByUser}
            xKey="date"
            yKey="clicks"
            height={220}
            color="var(--chart-blue)"
            />
          )}
        </Card>
        {/* Share of clicks — real data */}
        <Card className="p-6">
          <h2 className="font-semibold text-zinc-900 dark:text-white mb-1">Share of clicks</h2>
          <p className="text-xs text-zinc-400 mb-4">Top 5 links by volume</p>
          {loading ? (
            <ChartSkeleton height={180} />
          ) : shareData.every((d) => d.value === 0) ? (
            <ChartEmpty />
          ) : (
            <>
              <DonutStat
                data={shareData}
                height={180}
                centerLabel="click_count"
                centerValue={formatNumber(shareData.reduce((s, d) => s + d.value, 0))}
                />
              <div className="mt-5">
                <ChartLegend data={shareData} />
              </div>
            </>
          )}
        </Card>
      </div>

      {/* ── Top links table ── */}
      <Card className="p-6">
        <h2 className="font-semibold text-zinc-900 dark:text-white mb-1">Top links</h2>
        <p className="text-xs text-zinc-400 mb-4">Ranked by total clicks — click View to load its daily trend above</p>
        <TopLinksTable
          links={topLinks}
          loading={loading}
          selectedCode={selectedCode}
          onSelect={loadDaily}
          />
      </Card>
    </div>
  );
}


// const DEVICE_COLORS = {
//   Desktop: "#3b82f6",
//   Mobile:  "#22c55e",
//   Tablet:  "#f97316",
//   Other:   "#ef4444",
// };

// Demo device data — not stored in DB
// const DEMO_DEVICE_DATA = [
//   { name: "Desktop", value: 58, color: DEVICE_COLORS.Desktop },
//   { name: "Mobile",  value: 30, color: DEVICE_COLORS.Mobile  },
//   { name: "Tablet",  value: 9,  color: DEVICE_COLORS.Tablet  },
//   { name: "Other",   value: 3,  color: DEVICE_COLORS.Other   },
// ];
{/* Device distribution — demo data */}
{/* <Card className="p-6">
  <h2 className="font-semibold text-zinc-900 dark:text-white mb-1">Device distribution</h2>
  <p className="text-xs text-zinc-400 mb-4">Share of visits</p>
  <DonutStat
    data={DEMO_DEVICE_DATA}
    height={180}
    centerLabel="visits"
    centerValue={formatNumber(DEMO_DEVICE_DATA.reduce((s, d) => s + d.value, 0))}
  />
  <div className="mt-5">
    <ChartLegend data={DEMO_DEVICE_DATA} />
  </div>
</Card> */}